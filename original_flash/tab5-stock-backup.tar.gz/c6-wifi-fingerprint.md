# ESP32-C6 Wi-Fi co-processor — fingerprint

Captured 2026-09-02 from the stock firmware's boot log (`stock-boot.log`),
by resetting the P4 over USB and reading its console. Read-only; nothing was
written to either chip.

## Why there is no C6 firmware image in this backup

The C6 has its **own flash**, physically separate from the P4's 16 MB. It is
reachable from the P4 only over SDIO, which is a data transport — it offers no
flash read-back path. ESP-Hosted can *push* a firmware update to the slave
(write-only OTA); it cannot dump one.

Flashing or reading the C6 requires a **USB-TTL adapter on the reserved
download pads** on the Tab5 PCB (M5Stack sells a matching "ESP32 Downloader").
It cannot be done through the P4's USB-C port. See
<https://docs.m5stack.com/en/guide/restore_factory/m5tab5_c6_wifi>.

So this file is a fingerprint of the C6's *configuration as reported over the
link*, not an image. If the C6 is ever wiped, M5Stack publishes the factory
Wi-Fi firmware through M5Burner — restore from there, then compare against the
values below to confirm you are back to a matching setup.

## What the link reports

| Property | Value |
|---|---|
| Slave chip ID | 12 (ESP32-C6) |
| Host chip ID | 18 (ESP32-P4) |
| ESP board type | 13 |
| Capabilities | `0x0D` — WLAN, HCI over SDIO, BLE only |
| Transport | SDIO, 4-bit, 40 MHz, streaming mode |
| Function 0/1 blocksize | 512 / 512 |
| Host BT support | disabled (in this build) |
| Slave FW version | **not reported** by this ESP-Hosted build |

### SDIO pinout (P4 side)

| Signal | GPIO |
|---|---|
| CLK | 12 |
| CMD | 13 |
| D0 | 11 |
| D1 | 10 |
| D2 | 9 |
| D3 | 8 |
| Slave reset | 15 |

## Caveat

ESP-Hosted in this build prints no slave firmware version string, so there is no
version number to record — the capability word, board type and chip ID above are
the closest available identity. If you later rebuild the host with a newer
ESP-Hosted and it refuses to talk to this C6, that mismatch is the thing to
suspect first, and these values are your baseline.

## Other hardware confirmed by the same boot log

| Part | Detail |
|---|---|
| PSRAM | 256 Mbit (32 MB), x16, 2048-byte burst |
| Touch | **ST7123** — FW `1.80.1.16`, 720x1280, 10 points |
| IMU | BMI270 |
| Power monitor | INA226 |
| Audio in | ES7210, 4 mics, TDM, 16-bit |
| Audio out | ES8388 |
| Host app | `639d9cc`, ESP-IDF v5.4.2 |
| SoftAP | SSID `M5Tab5-UserDemo-WiFi`, DHCP 192.168.4.1 |

Note the touch controller: published Tab5 specs say GT911, but this unit reports
**ST7123**. Trust the board, not the spec sheet, when writing the touch driver.
