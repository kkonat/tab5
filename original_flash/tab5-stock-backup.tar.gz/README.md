# M5Stack Tab5 — stock flash backup

Full raw dump of the factory firmware, captured 2026-09-02.

## Device

| | |
|---|---|
| Board   | M5Stack Tab5 |
| Chip    | ESP32-P4 revision v1.3 |
| MAC     | 80:f1:b2:d1:41:b2 |
| Crystal | 40 MHz |
| Flash   | 16 MB (manufacturer 0x46, device 0x4018) |
| Link    | native USB-Serial-JTAG (VID 303A, PID 1001) |

## Contents

| File | Description |
|---|---|
| `tab5-backup-full.bin`        | Raw 16 MB flash image (16,777,216 bytes), offset 0x0 |
| `tab5-backup-full.bin.sha256` | SHA-256 of the image; verified by the restore scripts |
| `partition-table.csv`         | Partition table decoded from offset 0x8000 |
| `flash_id.log`                | esptool chip/flash detection output |
| `read_flash.log`              | esptool session log from the original dump |
| `stock-boot.log`              | Console log of the stock firmware booting (read-only capture) |
| `c6-wifi-fingerprint.md`      | ESP32-C6 Wi-Fi co-processor config, and why no C6 image is here |

## Partition layout

| Name | Type | Offset | Size |
|---|---|---|---|
| nvs            | data/nvs    | 0x9000   | 24K  |
| phy_init       | data/phy    | 0xf000   | 4K   |
| factory        | app         | 0x10000  | 10M  |
| human_face_det | data/spiffs | 0xa10000 | 400K |
| storage        | data/spiffs | 0xa74000 | 2M   |

The `human_face_det` SPIFFS partition confirms this is the factory demo firmware.

## Notes

The bootloader lives at **0x2000**, which is correct for the ESP32-P4 — offset
0x0 is erased (0xFF) by design. Do not mistake that for a truncated dump.

This is a raw dump of one specific unit, so its NVS carries that unit's
calibration and any Wi-Fi credentials stored at capture time. It restores this
board faithfully, but it is not a clean image to distribute to other boards.

## Restoring

From the repository root:

    scripts\restore-flash.ps1          # PowerShell
    ./scripts/restore-flash.sh         # bash

Both auto-detect the port, verify the SHA-256 before writing, and prompt for
confirmation (`-Force` / `-y` to skip).

For full options: `Get-Help scripts
estore-flash.ps1 -Detailed`, or
`./scripts/restore-flash.sh --help`.
